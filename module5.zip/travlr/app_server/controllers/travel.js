// Define the API endpoint for fetching trips
const tripsEndpoint = 'http://localhost:3000/api/trips';

// Define the options for the fetch request
const options = {
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    },
    cache: "no-store"
};

// GET travel view - async function to fetch data from API
const travel = async function (req, res, next) {
    try {
        // Fetch data from the API
        const response = await fetch(tripsEndpoint, options);

        // Convert the response to JSON
        const json = await response.json();
        let message = null;

        //check if the response is not an array
        if (!Array.isArray(json)) {
            message = 'API lookup error'; //set error message if not array
            json = []; //set json to an empty array avoiding rendering issues
        }
        //check if array is empty
        else if (!json.length) {
            message = 'None exist in this database!';
        }

        // Render the 'travel' view with the trips data and any message
        res.render('travel', { title: 'Travlr Getaways', trips: json, message: message });

    } catch (err) {
        // Catch and handle any errors during the fetch
        res.status(500).send(err.message);
        // Uncomment this line to log the error
        // console.log("Error fetching trips:", err);
    }
};

module.exports = {
    travel
};