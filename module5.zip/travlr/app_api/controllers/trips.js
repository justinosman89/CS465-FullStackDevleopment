const mongoose = require('mongoose');
const Trip = require('../models/travlr');

// GET: /trips - lists all trips
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({}).exec(); // Fetch all trips

        // Uncomment the following to show results of query on the console
        // console.log(trips);

        if (!trips) { // If no trips are found
            return res
                .status(404)
                .json({ message: 'No trips found' });
        } else { // Return the list of trips
            return res
                .status(200)
                .json(trips);
        }
    } catch (err) { // Catch and handle errors
        return res
            .status(500)
            .json({ message: 'Error retrieving trips', error: err });
    }
};

// GET: /trips/:tripCode - find a trip by its code
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({ 'code': req.params.tripCode }).exec(); // Find trip by code

        // Uncomment the following line to show results of query on the console
        // console.log(trip);

        if (!trip) { // If no trip is found
            return res
                .status(404)
                .json({ message: `Trip with code ${req.params.tripCode} not found` });
        } else { // Return the trip
            return res
                .status(200)
                .json(trip);
        }
    } catch (err) { // Catch and handle errors
        return res
            .status(500)
            .json({ message: 'Error retrieving trip', error: err });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode
};
